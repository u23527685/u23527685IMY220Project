build
docker build -t deliverable_1 .

run
docker run --name  d1demo -p 3000:3000 deliverable_1

git-repository:https://github.com/u23527685/u23527685IMY220Project.git