build
docker build -t deliverable2 .

run
docker run --name  d2demo -p 3000:3000 deliverable2

git-repository:https://github.com/u23527685/u23527685IMY220Project.git

connection string:
"mongodb+srv://ProjectUser:ProjecyUser77@databases.rkr0bx9.mongodb.net/?retryWrites=true&w=majority&appName=Databases"
